<table border="1" aling="center" width="732">
		<tr>
			<th colspan="3"><img src="logo2.jpg" border="0" alt="logo_catdog" width="732" height="194" /></th>
		</tr>
		<tr>
			<td colspan="3">
				<br>
			<h3>HOLA	<?php echo "".$row[0]." " $row[1];?></h3>
			<p>la clave que le hemos asignado es <?php echo "".$pass;?></p>
				<br><br><br><br>
			</td>
		</tr>
				<tr>
					<th colspan="3"><center>Todos Los Derechos Reservados  2016</center></th>
				</tr>
	</table>