<center>
<table class="letragrande">
	<tr>
		<td colspan="7">
			<textarea name="d_definitivo" Readonly="readonly" class=estilotextarea title="diagnostico definitivo" ><?php if(isset($row5[17])){echo $row5[17];}?></textarea>
		</td>
	</tr>
</table>
</center>