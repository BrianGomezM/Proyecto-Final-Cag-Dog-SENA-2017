<center>
<table class="letragrande">
					<tr>
						<td>
							PHC:     
						</td>
						<td >
							<input type="text" Readonly="readonly" name="phc"  title="phc" <?php if(isset($row5[19])){echo "value='".$row5[19]."'";}?>>      
						</td>
						<td>
							Quimicas Sericas:
						</td>
						<td >
							<input type="text" Readonly="readonly" name="quimicas_sericas"  title="quimicas sericas" <?php if(isset($row5[20])){echo "value='".$row5[20]."'";}?>>      
						</td>
						<td>
							Uroanalisis:
						</td>
						<td >
							<input type="text" Readonly="readonly" name="uroanalisis"  title="uroanalisis" <?php if(isset($row5[21])){echo "value='".$row5[21]."'";}?>>      
						</td>
					</tr>
					<tr>
					<td>
					</td>
					</tr>
					<tr>
						<td>
							Caprologia:
						</td>
						<td >
							<input type="text" name="caprologia" Readonly="readonly" title="caprologia" <?php if(isset($row5[22])){echo "value='".$row5[22]."'";}?>>      
						</td>
						<td>
							Imagenologia:
						</td>
						<td >
							<input type="text" name="imagenologia" Readonly="readonly" title="imagenologia" <?php if(isset($row5[23])){echo "value='".$row5[23]."'";}?>>      
						</td>
						<td>
							Patologias:
						</td>
						<td >
							<input type="text" name="patologias" Readonly="readonly" title="patologia" <?php if(isset($row5[24])){echo "value='".$row5[24]."'";}?>>      
						</td>
					</tr>
					<tr>
					<td>
					</td>
					</tr>
					<tr>
						<td>
							Citologias:
						</td>
						<td >
							<input type="text" name="Citologias" Readonly="readonly" title="citologia" <?php if(isset($row5[25])){echo "value='".$row5[25]."'";}?>>      
						</td>
						<td>
							RSepaje Koh
						</td>
						<td >
							<input type="text" name="rspaje_koh" Readonly="readonly" title="rsepaje koh" <?php if(isset($row5[26])){echo "value='".$row5[26]."'";}?>>      
						</td>
						<td>
							Test Diagnostico
						</td>
						<td >
							<input type="text" name="test_diagnostico" Readonly="readonly" title="text diagnostico" <?php if(isset($row5[27])){echo "value='".$row5[27]."'";}?>>      
						</td>
					</tr>
</table>
</center>