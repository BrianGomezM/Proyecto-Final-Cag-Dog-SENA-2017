<center><table class="letragrande">
	<tr>
		<td colspan="7">
			<textarea  name="d_diferencial" Readonly="readonly" class=estilotextarea title="diagnostico diferencial" ><?php if(isset($row5[18])){echo $row4[18];}?></textarea>
		</td>
	</tr>
</table>
</center>