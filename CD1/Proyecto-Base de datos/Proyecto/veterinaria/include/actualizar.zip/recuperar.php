<?php
include ('include/conex.php');
$link= Conectarse();
$msn=$_POST['msn_recu'];
$num=$_POST['num_recu'];
$q2=  mysql_query ('select p_nombre,p_apellido,email from propietario where numero_tipo="'.mysql_real_escape_string($num).'"
AND email="'.mysql_real_escape_string($msn).'"');
		if ($exite2 = mysql_fetch_object($q2))	
		{
			$d="select p_nombre,p_apellido,email,id_propietario from propietario where numero_tipo='$num'";
			$p1= mysql_query($d,$link);
			$row=mysql_fetch_row($p1);
			$pass= rand(1000, 3000);
			$mensaje= "
			<html>
			<body>
			<table border='0' aling='center' width='732'>
			<tr>
			<th colspan='3'>
			<img src='http://s2.subirimagenes.com/otros/previo/thump_9508301logo2.jpg' border='0' width='732' height='194'/></th>
			</tr>
			<tr>
			<td colspan='3'><br>
			<h3>HOLA	$row[0] $row[1]</h3>
			<p>la clave que le hemos asignado es $pass
			</td>
			</tr>
			<tr>
					<th colspan='3'><center>Veterinaria San Roque</center></th>
				</tr>
			</table>
			
			</p>
			</body>
			</html>
			";
			//echo "".$mensaje;
			$título= "Cambio de clave ";
			//// Para enviar un correo HTML, debe establecerse la cabecera Content-type
			$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
			$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

			// Cabeceras adicionales
			$cabeceras .= 'From: Cambio de Clave de CatDog <admin@catdog.com>' . "\r\n";
			///////////////////////////////////////////////////////////////////////////

			//funcion para mensajes a correos mail(para,asunto, mensaje);
			mail($msn, $título, $mensaje, $cabeceras);
			$slq="UPDATE `sespa_veterinaria`.`propietario` SET `clave` = '$pass' WHERE `id_propietario`='$row[3]'";
				$conf=mysql_query($slq,$link);
					if (!$conf)
					{
						  echo '<script language="javascript">alert("error inesperado");
				   
					</script>';
				
						
					}
					else
					{
					
					}
			echo '<script language="javascript">alert("Te enviamos un mensaje a tu correo con la nueva clave");
	     var pagina="index.php"
	     location.href=pagina				
	     </script>';
		
		}
		else
		{
		 echo '<script language="javascript">alert("el numero de documento es incorrrecto y/o correo incorrecto");
	     var pagina="index.php"
	     location.href=pagina				
	     </script>';
		}



?>