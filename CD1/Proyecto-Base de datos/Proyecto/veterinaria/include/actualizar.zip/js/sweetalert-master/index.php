<html>
<head>
<title>Menu Desplegable</title>
 <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
 <script src="dist/sweetalert-dev.js"></script>
 <link rel="stylesheet" href="dist/sweetalert.css">
</head>
<body>
<script>
alert("ola");
swal({   title: "Error!",   text: "Here's my error message!",   type: "info",   confirmButtonText: "Cool" });
</script>
</body>
</html>