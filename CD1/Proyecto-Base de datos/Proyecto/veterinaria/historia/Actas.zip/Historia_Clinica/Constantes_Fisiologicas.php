<center><table class="letragrande">
					<tr>
						
						<td>
							Frecuencia Cardiaca:
						</td>
						<td>
							<input type="Text" name="frecuencia_cardiaca"  title="frecuencia cardiaca" <?php if(isset($row4[29])){echo "value='".$row4[29]."'";}?>>
							
						</td>
						
						<td>
							Frecuencia Respiratoria:
						</td>
						<td>
							<input type="Text" name="frecuencia_respiratoria"  title="frecuencia respiratoria" <?php if(isset($row4[30])){echo "value='".$row4[30]."'";}?>>
						</td>
					</tr>
					<tr><td colspan="5"><br></td></tr>
					
					<tr>
						
						<td>
							Pulso:
						</td>
						<td>
							<input type="Text" name="pulso"  title="pulso" <?php if(isset($row4[31])){echo "value='".$row4[31]."'";}?>>
						</td>
						<td>
							Temperatura Rectal:
						</td>
						<td>
							<input type="Text" name="temperatura_rectal"  title="temperatura rectal" <?php if(isset($row4[32])){echo "value='".$row4[32]."'";}?>>
						</td>
					</tr>
					</table></center>