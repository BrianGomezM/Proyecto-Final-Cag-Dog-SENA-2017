<center>
<table class="letragrande">
	<tr>
		<td colspan="6">
			<textarea name="tratamiento"  class=estilotextarea title="tratamiento"><?php if(isset($row4[44])){echo $row4[44];}?></textarea>		
		</td>
	</tr>
	
</table><br>

	<table><tr>
			<td>
				<input type="submit" name="Descargar" value="Descargar"  id="subt3" />
			</td>
		</tr>
		<tr>
			<td>
				<input type="hidden" name="user" id="user" value="<?php if (isset($row4[45])){echo $row4[45];} ?>"/>
				<input type="hidden" name="mas" id="mas" value="<?php if (isset($row4[46])){echo $row4[46];} ?>"/>
			</td>
		</tr>
		
	</table>
	</center>