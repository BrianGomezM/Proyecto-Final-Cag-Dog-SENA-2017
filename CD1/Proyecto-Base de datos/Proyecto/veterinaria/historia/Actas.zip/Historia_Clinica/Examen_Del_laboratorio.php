<center>
<table class="letragrande">
					<tr>
						<td>
							PHC:     
						</td>
						<td >
							<input type="text" name="phc"  title="phc" <?php if(isset($row4[33])){echo "value='".$row4[33]."'";}?>>      
						</td>
						<td>
							Quimicas Sericas:
						</td>
						<td >
							<input type="text" name="quimicas_sericas"  title="quimicas sericas" <?php if(isset($row4[34])){echo "value='".$row4[34]."'";}?>>      
						</td>
						<td>
							Uroanalisis:
						</td>
						<td >
							<input type="text" name="uroanalisis"  title="uroanalisis" <?php if(isset($row4[35])){echo "value='".$row4[35]."'";}?>>      
						</td>
					</tr>
					<tr>
					<td>
					</td>
					</tr>
					<tr>
						<td>
							Caprologia:
						</td>
						<td >
							<input type="text" name="caprologia"  title="caprologia" <?php if(isset($row4[36])){echo "value='".$row4[36]."'";}?>>      
						</td>
						<td>
							Imagenologia:
						</td>
						<td >
							<input type="text" name="imagenologia"  title="imagenologia" <?php if(isset($row4[37])){echo "value='".$row4[37]."'";}?>>      
						</td>
						<td>
							Patologias:
						</td>
						<td >
							<input type="text" name="patologias"  title="patologia" <?php if(isset($row4[38])){echo "value='".$row4[38]."'";}?>>      
						</td>
					</tr>
					<tr>
					<td>
					</td>
					</tr>
					<tr>
						<td>
							Citologias:
						</td>
						<td >
							<input type="text" name="Citologias"  title="citologia" <?php if(isset($row4[39])){echo "value='".$row4[39]."'";}?>>      
						</td>
						<td>
							RSepaje Koh
						</td>
						<td >
							<input type="text" name="rspaje_koh"  title="rsepaje koh" <?php if(isset($row4[40])){echo "value='".$row4[40]."'";}?>>      
						</td>
						<td>
							Test Diagnostico
						</td>
						<td >
							<input type="text" name="test_diagnostico"  title="text diagnostico" <?php if(isset($row4[41])){echo "value='".$row4[41]."'";}?>>      
						</td>
					</tr>
</table>
</center>