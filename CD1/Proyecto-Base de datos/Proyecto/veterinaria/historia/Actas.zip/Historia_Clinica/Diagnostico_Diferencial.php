<center><table class="letragrande">
	<tr>
		<td colspan="7">
			<textarea  name="d_diferencial" class=estilotextarea title="diagnostico diferencial" ><?php if(isset($row4[42])){echo $row4[42];}?></textarea>
		</td>
	</tr>
</table>
</center>