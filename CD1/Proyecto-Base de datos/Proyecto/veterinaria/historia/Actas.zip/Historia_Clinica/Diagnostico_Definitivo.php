<center>
<table class="letragrande">
	<tr>
		<td colspan="7">
			<textarea name="d_definitivo" class=estilotextarea title="diagnostico definitivo" ><?php if(isset($row4[43])){echo $row4[43];}?></textarea>
		</td>
	</tr>
</table>
</center>