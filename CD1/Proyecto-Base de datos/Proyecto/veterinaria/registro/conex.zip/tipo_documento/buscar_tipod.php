<?php
include('../conex/conex.php');
$link= Conectarse();
$tipodoc=$_POST['tipodoc'];
$propietario="SELECT tipo_document.tipo FROM  tipo_document WHERE tipo='$tipodoc'";

$confir=mysql_query($propietario,$link);
if ($ob=mysql_fetch_object($confir))
{
$dt="SELECT tipo_document.tipo FROM  tipo_document WHERE tipo='$tipodoc'";
$confir2=mysql_query($dt,$link);
$row=mysql_fetch_row($confir2);
header('Location:../tipo_documento/editar_tipodoc.php?user='.$row[0].'&&tipodoc='.$tipodoc);	
}
else
{
	 echo '<script language="javascript">alert("el tipo de documento no existe");
				   	var pagina="../tipo_documento/registrar_tipod.php"
				   	location.href=pagina				
					</script>';
}
?>