<?php 
function Conectarse() 
{ 
  if (!($link=mysql_connect("localhost","sespa_root","root132"))) 
	{ 
      echo "conectando a la base de datos."; 
      exit(); 
   } 
	 if (!mysql_select_db("sespa_veterinaria",$link)) 
   { 
   echo '<script language="javascript">alert("error en conectar al a base de datos archivo conex de richard");
				   	var pagina="index.php"
				   	location.href=pagina				
					</script>';
      exit(); 
   } 
   return $link;
} 
?>