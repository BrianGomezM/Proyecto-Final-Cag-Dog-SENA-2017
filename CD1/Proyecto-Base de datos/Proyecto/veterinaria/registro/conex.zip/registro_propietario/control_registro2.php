<?php
include('../conex/conex.php');
$link=Conectarse();

$documento=$_GET['documento'];

$user=$_POST['user'];
$editar=$_POST['editar'];
$nombre1=$_POST['nombre1'];
$nombre2=$_POST['nombre2'];
$apellido1=$_POST['apellido1'];
$apellido2=$_POST['apellido2'];
$tipodocu=$_POST['tipodocu'];
$documento=$_POST['documento'];
$telefono=$_POST['telefono'];
$direccion=$_POST['direccion'];
$correo=$_POST['correo'];
$estado=$_POST['estado'];
$roll=$_POST['roll'];

$sql="UPDATE propietario SET 
p_nombre= '$nombre1',
s_nombre= '$nombre2',
p_apellido= '$apellido1',
s_apellido= '$apellido2',
id_tipo_docu= '$tipodocu',
numero_tipo= '$documento',

celular= '$telefono',
direccion= '$direccion',
email= '$correo',
id_est_propi= '$estado',
id_roll= '$roll' WHERE  propietario.id_propietario ='$editar'";

	//echo $sql;

$result2=mysql_query($sql,$link); echo '<script language="javascript">alert("el registro se actualizo exitosamente ");
														var pagina="../registro_propietario/registro_usuario.php";
														location.href=pagina				
														</script>';
	 
//header('Location:../registro_propietario/registro_usuario.php?user='.$user);


?>

