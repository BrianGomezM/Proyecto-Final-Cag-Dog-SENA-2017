<?php
include('../conex/conex.php');
$link=Conectarse();
$user=$_POST['1'];

$nombre1=$_POST['nombre1']; 
$nombre2=$_POST['nombre2'];
$apellido1=$_POST['apellido1'];
$apellido2=$_POST['apellido2'];
$tipodocu=$_POST['tipodocu'];
$documento=$_POST['documento'];
$clave= rand(1000, 9000);
$telefono=$_POST['telefono'];
$direccion=$_POST['direccion'];
$correo=$_POST['correo'];
$estado=$_POST['estado'];
$validar=0;



$sql2="SELECT * FROM propietario WHERE numero_tipo='$documento'";
 $result2=mysql_query($sql2,$link);
 if($row=mysql_fetch_array($result2))
 {
	
	 echo '<script language="javascript">alert("El numero de documeto ya existe existe ");
														var pagina="../registro_propietario/registro_usuario.php";
														location.href=pagina				
														</script>';
	 
 }
 else
 {

$explode = explode("@", $correo);

//Lista de correo válidos
$permitidos=array('hotmail.com','gmail.com','yahoo.com','misena.edu.co');

//Cantidad de correos válidos
$cantidad=count($permitidos);
//Comparar con la lista de correos válidos
for ($i=0; $i < $cantidad; $i++) { 

if ($permitidos[$i]==$explode[1]) $validar=1;

}
//Si es válido registrar usuario
if($validar==1){
//Registrar usuario <----------
$sql="INSERT INTO propietario(
id_propietario ,
p_nombre ,
s_nombre ,
p_apellido ,
s_apellido ,
id_tipo_docu ,
numero_tipo ,
clave ,
celular ,
direccion ,
email ,
id_roll,
id_est_propi ,
online 
)
VALUES (
NULL , '$nombre1', '$nombre2', '$apellido1', '$apellido2', '$tipodocu', '$documento', '$clave', '$telefono', '$direccion', '$correo','2', '$estado','1')";

$mensaje= "
			<html>
			<body>
			<table border='0' aling='center' width='732'>
			<tr>
			<th colspan='3'>
			<img src='http://s2.subirimagenes.com/otros/previo/thump_9508301logo2.jpg' border='0' width='732' height='194'/></th>
			</tr>
			<tr>
			<td colspan='3'><br>
			<h3>HOLa $nombre1 $nombre $apellido1 $apellido2 </h3>
			
			<p>la clave que le hemos asignado es $clave
			</td>
			</tr>
			<tr>
					<th colspan='3'><center>Veterinaria San Roque</center></th>
				</tr>
			</table>
			
			</p>
			</body>
			</html>
			";
			//echo "".$mensaje;
			$título= "Cambio de clave ";
			//// Para enviar un correo HTML, debe establecerse la cabecera Content-type
			$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
			$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

			// Cabeceras adicionales
			$cabeceras .= 'From: Cambio de Clave de CatDog <axel115@misena.edu.co>' . "\r\n";
			///////////////////////////////////////////////////////////////////////////

			//funcion para mensajes a correos mail(para,asunto, mensaje);
			mail($correo, $título, $mensaje, $cabeceras);


  $result=mysql_query($sql,$link);
  if(!$result)
  {
		 echo '<script language="javascript">alert("error al registrar propietario ");
		 var pagina="../registro_propietario/registro_usuario.php";
														location.href=pagina				
														</script>';
  }
  else{
	  	 echo '<script language="javascript">alert("usuario  registrado");
		 var pagina="../registro_propietario/registro_usuario.php";
														location.href=pagina				
														</script>';
  
	
 }
}

//Si no es válido imprimir mensajexscdw2
echo '<script language="javascript">alert("correo no valido");
		 var pagina="../registro_propietario/registro_usuario.php";
														location.href=pagina				
														</script>';
}

 ?>
 