<?php
												//desparacitacion Almacenar Informacion variables //
	include('../conex/conex.php');						
	$link=Conectarse();	
	$editar=$_GET['editar'];
	$motivos=$_GET['motivos'];	
	$fecha=$_GET['fecha'];
	$id_mas=$_GET['id_mas'];
	$id_despa=$_GET['id_despa'];
	if ($editar==1)
	{
	$sqleditar="UPDATE desparacitacion SET fecha = '$fecha', motivos = '$motivos' WHERE desparacitacion.id_despa = '$id_despa'";
	if($resulteditar=mysql_query($sqleditar,$link))
			{header('location:desparasitacion.php?Ediccion_Correcta=1');}
		else  
			{header('location:desparasitacion.php?Ediccion_Incorrecta=2');}
	}
	else
	{
		$sql="INSERT INTO  desparacitacion (fecha ,id_mascota ,actividad ,id_propietario)VALUES ('$fecha', '$id_mas', '$motivos', '$veterinario');";
		if($result=mysql_query($sql,$link))
			{header('location:desparasitacion.php?Registro_Correctoo=1');}
		else  
			{header('location:desparasitacion.php?Registro_incorrecto=2');}
	}	
?>