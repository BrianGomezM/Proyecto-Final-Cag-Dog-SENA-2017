<?php
												//Vacunacion Almacenar Informacion variables //
	include('../conex/conex.php');						
	$link=Conectarse();	
	$editar=$_GET['editar'];
	$motivos=$_GET['motivos'];	
	$fecha=$_GET['fecha'];
	$id_mas=$_GET['id_mas'];
	$id_vacuna=$_GET['id_vacuna'];
	if ($editar==1)
	{
	$sqleditar="UPDATE vacunacion SET fecha = '$fecha', motivos = '$motivos' WHERE vacunacion.id_vacuna = '$id_vacuna'";
	if($resulteditar=mysql_query($sqleditar,$link))
			{header('location:vacunacion.php?Ediccion_Correcta=1');}
		else  
			{header('location:vacunacion.php?Ediccion_Incorrecta=2');}
	}
	else
	{
		$sql="INSERT INTO  vacunacion (fecha ,id_mascota ,actividad ,id_propietario)VALUES ('$fecha', '$id_mas', '$motivos', '$veterinario');";
		if($result=mysql_query($sql,$link))
			{header('location:vacunacion.php?Registro_Correctoo=1');}
		else  
			{header('location:vacunacion.php?Registro_incorrecto=2');}
	}	
?>